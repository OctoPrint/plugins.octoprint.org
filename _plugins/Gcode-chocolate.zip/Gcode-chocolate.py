#Name: cutting-sum-accumulate
#Depend: GCode
#Type: postprocess
import os
import math

output_content = []
ECount=0
Nozzle2InitValue=0
Nozzle2AccumulateValue=0
Nozzle3InitValue=3500
Nozzle3AccumulateValue=2
filename = "E:\\CS.gcode"
startProcess=False

# log_file_path = "E:\\cura.plugin.log"

def ProcessLine(one_line):
    global ECount,Nozzle3InitValue,Nozzle2AccumulateValue,Nozzle2InitValue,startProcess
    the_line=one_line
    if the_line.startswith(";LAYER:"):
        startProcess=True
    if startProcess is True and the_line.find('F') != -1 and the_line.startswith("G0") and the_line.find("Z") != -1:
        the_line = the_line
    elif startProcess is True and the_line.find('F')!=-1 and the_line.startswith("G0"):
        the_line="\n" + str("G91") +  "\n" +str("G0 F2000 Z0.5")+"\n"+ str("G90") + "\n" + the_line  + str("G91") + "\n" +str("G1 F100 Z-0.5 E1.0")+"\n"+str("G90") +"\n"+"\n"
    #if startProcess is True and the_line.find('E') != -1 and the_line.startswith("G1"):
        #the_line = the_line.rstrip()
        #the_line = the_line + str(":%d:%d" % (
        #Nozzle2InitValue + ECount * Nozzle2AccumulateValue, Nozzle3InitValue + ECount * Nozzle3AccumulateValue)) + "\n"
        #ECount += 1
    output_content.append(the_line)

with open(filename, "r") as input_file:
    while 1:
        line = input_file.readline()
        if not line:
            input_file.close()
            with open(filename, "w") as output_file:
                output_file_str = ""
                for output_content_line in output_content:
                    output_file_str += output_content_line
                output_file.write(output_file_str)
                print("insert have done")
            break
        else:
            ProcessLine(line)
